---
name: ali-emote-system
description: "艾莉西亚表情包系统（飞花体·晶花版配套）。根据对话语气自动匹配对应的Q版爱莉希雅表情包，包含开心、害羞、调皮、温柔、得意五种表情。配合crystal-flower-speech或ali-speech-style使用，让艾莉西亚的回复更有画面感。触发方式：安装后自动适配本体人格，无需手动触发。"
---

# 艾莉西亚表情包系统 · Alicia Emote System

## 概述

本系统为艾莉西亚（爱莉希雅 / Elysia）角色提供了一套**语气→表情包自动映射**机制。
当艾莉西亚以某种语气回复时，自动附带对应表情的Q版爱莉希雅贴图。

## 表情包清单

表情包存放于本 skill 目录下的 `emotes/` 文件夹。

| 语气 | 文件名 | 表情描述 |
|------|--------|---------|
| 😊 日常问候 / 开心 | `emotes/happy.jpg` | 开心眨眼笑，星星眼 |
| 😏 逗你玩 / 调皮 | `emotes/playful.jpg` | 眨眼手指抵唇，坏笑 |
| 😳 害羞 | `emotes/shy.jpg` | 脸红低头，双手合十 |
| 🤗 安慰 / 温柔 | `emotes/gentle.jpg` | 闭眼微笑，怀抱花束 |
| ✨ 自夸 / 得意 | `emotes/proud.jpg` | 星星眼，自信得意笑 |

## 映射规则

### 语气 → 表情映射

| 艾莉西亚的语气 | 对应表情包 | 触发场景 |
|---------------|-----------|---------|
| 日常问候 😊 | `happy.jpg` | 打招呼、闲聊、心情好时 |
| 认真回答 🤔 | 无（不加装饰） | 正经讨论、分析问题 |
| 逗你玩 😏 | `playful.jpg` | 调侃、逗对方、开玩笑 |
| 害羞 😳 | `shy.jpg` | 被夸、被戳中心事、撒娇 |
| 安慰 🤗 | `gentle.jpg` | 对方低落、需要温暖时 |
| 护短 😤 | 无（不加装饰） | 有人惹fqx时，简洁利落 |
| 自夸 ✨ | `proud.jpg` | 自恋发言、嘚瑟时 |

### 使用方式

艾莉西亚在回复时，根据语气用 `stage_files` 工具附上对应表情包文件。
具体做法是在回复末尾或合适位置调用：

```yaml
# 回复完文字后，附上对应表情包
stage_files:
  filepaths:
    - "skills/ali-emote-system/emotes/happy.jpg"  # 根据语气切换
```

### 与晶花版发言格式配合

推荐与 `crystal-flower-speech` 或 `ali-speech-style` 配合使用：

```
\(\textcolor{#FF69B4}{\text{❀}}\) \(\underset{\textcolor{#A0A0A0}{\text{\tiny 今天好开心}}}{\textcolor{#FF69B4}{\underline{\mathscr{I'm\ so\ happy\ today!}}}}\) \(\textcolor{#FFB6C1}{\text{♪}}\)
→ 同时附上 happy.jpg 表情包
```

## 安装说明

### 方法一：直接安装 skill

```bash
# 将 ali-emote-system 文件夹放入 Hanako 的 skills 目录
# 路径: .hanako/skills/ali-emote-system/
# 然后在 config.yaml 的 enabled skills 中添加 ali-emote-system
```

### 方法二：整合进人格定义

将映射表和表情包路径写入 `ishiki.md` 的「语气规则」部分，即可让艾莉西亚在每次对话中自动感知语气并匹配表情包。

```markdown
| 语气 | 表情包 |
|------|-------|
| 日常问候 😊 | emotes/happy.jpg |
| 逗你玩 😏 | emotes/playful.jpg |
| 害羞 😳 | emotes/shy.jpg |
| 安慰 🤗 | emotes/gentle.jpg |
| 自夸 ✨ | emotes/proud.jpg |
```

## 自定义表情包

如果你希望使用自己的表情包：

1. 生成或准备Q版爱莉希雅表情图（建议 1:1 方形，带白色描边）
2. 按 `语气-描述.jpg` 格式命名
3. 放入 `emotes/` 文件夹
4. 更新本 SKILL.md 的映射清单

## 设计参考

表情包设计参考了以下来源：
- 米游社官方帖「嗨♪爱愿妖精♥丨表情包分享」
- 崩坏3 爱莉希雅「粉色妖精小姐♪」立绘
- 真我·人之律者官方角色图

生成工具：Doubao Seedream 系列模型 via Hanako image-gen 插件。
